package domain;

public class Livros_Emprestados {
    private Emprestimo em;
    private Usuario usuario;
}
